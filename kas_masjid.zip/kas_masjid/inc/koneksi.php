<?php
$koneksi = new mysqli ("localhost","root","","gratis_masjid");
?>